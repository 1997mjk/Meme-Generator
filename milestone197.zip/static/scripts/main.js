$(document).ready(function () {

  var data = [];
  var activeIdx = -1;
  var memes = ["DistractedBoyfriend", "IsThisAPigeon", "SurprisedPikachu", "ExpandingBrain", "TwoButtons", "BatmanRobin"];
  var memePath = "../../templates/";

  getMemes();

  function getMemes() {
    renderMemesTemplates();
    renderMemeList();
  }

  // makes a list  of questions which all have the question text and a data-qid attribute
  // that allows you to access their _id by doing $whateverjQueryObjectYouHave.data('qid')
  function renderMemeList() {
    $('#memes').html(
        memes.map((i) => '<li id="' + i + '">' + i + '</li>').join('')
    )
  }

  function renderMemesTemplates() {
    if (activeIdx > -1) {
      $('#show-meme').css('display', 'block');
      $('meme').text(memes[activeIdx]);
    } else {
      console.log(activeIdx);
      $('#show-meme').css('display', 'none');
    }
  }

  $('#memes').on('click', 'li', function () {
    var _id = $(this)[0].innerText;
    console.log(_id);
    var i = 0;
    for (i = 0; i < memes.length; i++) {
      if (memes[i] === _id) {
        activeIdx = i;
      }
    }

    renderMemesTemplates();
    renderImage();
  })

  function renderImage() {

    //TODO: ERASE PRE-EXISTING IMAGE 
    //TODO: RESIZE IMAGE 
    var img = document.createElement("img");
    img.src = memePath + memes[activeIdx] + ".jpg";
    var src = document.getElementById("meme-info");
    src.appendChild(img);
    console.log("Showing Image:" + img.src);
  }

  $('#show-meme').on('click', function () {
    //TODO: Add Text Adding Function

  })

  //TODO: Modify to EXPORT img
  // $('#submit-question').on('click', function () {
  //   var qText = $('#question-text').val();
  //   $.ajax({
  //     url: '/api/addQuestion',
  //     data: { questionText: qText },
  //     type: 'POST',
  //     success: function(res) {
  //       console.log(res);
  //       $('.modal').css('display', 'none');
  //     }
  //   })
  // })


})
