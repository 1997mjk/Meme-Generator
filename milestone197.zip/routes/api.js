var express = require('express')
var router = express.Router();
var Question = require('../models/question.js')
var Meme = require('../models/meme.js')

router.get('/getQuestions', function (req, res, next) {
  questions = Question.find({}, function (err, result) {
    if (err) next(err)
    res.json(result);
  })
})

router.get('/getMemes', function (req, res, next) {
  memes = Meme.find({}, function (err, result) {
    if (err) next(err)
    res.json(result);
  })
})

router.post('/addQuestion', function (req, res, next) {
  var { questionText } = req.body;
  var author = req.session.user;
  var q = new Question({ questionText, author })
  q.save(function (err, result) {
    if (err) next(err);
    res.json({ status: 'OK' });    
  })
})

router.post('/answerQuestion', function (req, res, next) {
  var { answer } = req.body;
  var { qid } = req.body;
  Question.findById(qid, function (err, question) {
      question.answer = answer;
      question.save(function (saveErr, result) {
          if (saveErr) next(saveErr);
          res.json({ success: 'OK' }); 
      })
  })
})

module.exports = router;
